| CLI | Description |
|-----|-------------|
| `bump-version-cli` | Semantic versioning + changelogs |
| `commit-gh-cli` | GitHub commit automation |
| `folder-tree-cli` | Visual folder structure + docs |
| `radar-love-cli` | Simulated secret leaks + scans |
| `repository-audit-cli` | Repo hygiene & reporting |
| `repository-backup-cli` | Modular backup + restore |
| `self-doc-gen-cli` | Generate README.md from scripts |
